# Official Starbuzz Discount Module.
#
# Copyright (c) 2009 by Starbuzz Corporation.
# All Rights Reserved.
#
# This function calculates a 5% discount on a price.
def discount(price):
    return 0.95 * price
