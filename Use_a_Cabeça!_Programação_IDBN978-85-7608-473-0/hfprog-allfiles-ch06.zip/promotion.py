def discount(price): 
    return 0.9 * price
